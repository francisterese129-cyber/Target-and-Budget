export type Category = "Budgeting" | "Saving" | "Making Money Online" | "Side Hustles";

export type Post = {
  slug: string;
  title: string;
  excerpt: string;
  category: Category;
  date: string; // ISO
  readTime: string;
  featured?: boolean;
  content: string[];
};

export const categories: Category[] = [
  "Budgeting",
  "Saving",
  "Making Money Online",
  "Side Hustles",
];

export const posts: Post[] = [
  {
    slug: "zero-based-budget-that-actually-sticks",
    title: "The Zero-Based Budget That Actually Sticks",
    excerpt:
      "Most budgets fail in week three, not month three. Here's a version of zero-based budgeting built around how people actually spend, not how spreadsheets wish they would.",
    category: "Budgeting",
    date: "2026-06-02",
    readTime: "7 min read",
    featured: true,
    content: [
      "Every dollar gets a job before the month begins — that's the whole idea behind zero-based budgeting. Income minus every planned expense, saving, and debt payment should equal zero. Not because you're spending it all, but because you've decided where all of it goes ahead of time.",
      "The version that fails is the one built in a single sitting on the first of the month, with categories that look good on paper: groceries, rent, 'miscellaneous.' That last category is where the budget quietly dies, because miscellaneous is where real life happens.",
      "Start with three passes instead of one. Pass one: fixed costs — rent, insurance, minimum debt payments, subscriptions. These don't move, so list them first and get them out of the way. Pass two: the variable costs you can actually predict, like groceries, gas, and your coffee habit. Give these real numbers pulled from last month's statements, not aspirational ones. Pass three: the categories that catch what's left — a genuine buffer line, plus savings and extra debt payments.",
      "That buffer line is the difference between a budget that survives contact with a birthday party, a flat tire, or a friend's wedding, and one that collapses the first week something unplanned happens. Aim for five to ten percent of your income sitting in a 'life happens' category, separate from your emergency fund.",
      "Review weekly, not monthly. A ten-minute Sunday check-in — comparing what you planned to spend in each category against what actually left your account — catches drift while it's still a five-dollar problem instead of a two-hundred-dollar one.",
      "The goal isn't a perfect budget. It's a budget you'll still be using in December.",
    ],
  },
  {
    slug: "50-30-20-rule-when-your-income-is-irregular",
    title: "The 50/30/20 Rule, Adapted for Irregular Income",
    excerpt:
      "Freelancers, commission earners, and side hustlers can still use the classic 50/30/20 split — it just needs a buffer month built in first.",
    category: "Budgeting",
    date: "2026-05-18",
    readTime: "6 min read",
    content: [
      "The standard 50/30/20 rule — needs, wants, savings — assumes a paycheck that looks the same every month. If your income moves with the seasons, with client work, or with tips, that assumption breaks down fast.",
      "The fix isn't a different rule. It's a different starting point: pay yourself a salary. Route all incoming money into one holding account, then transfer yourself a consistent, modest 'paycheck' from it every two weeks, based on your lowest-earning month from the past year. Everything above that baseline stays in the holding account as a buffer.",
      "Once that fixed paycheck exists, the 50/30/20 split works exactly as intended: fifty percent needs, thirty percent wants, twenty percent savings and debt payoff, calculated against a number that doesn't swing wildly from month to month.",
      "In strong months, the surplus sitting in your holding account does double duty — it tops up your buffer until it covers three full paychecks, and only after that does extra income flow toward bigger savings goals or debt payoff.",
      "This structure trades a little short-term flexibility for a lot of long-term calm. You stop reacting to whichever month you happen to be in, and start budgeting against a number you actually control.",
    ],
  },
  {
    slug: "sinking-funds-for-expenses-that-arent-surprises",
    title: "Sinking Funds: Planning for the Expenses That Aren't Really Surprises",
    excerpt:
      "Car repairs, holiday gifts, and annual insurance bills feel like emergencies, but they're predictable. A sinking fund turns them into a line item instead of a crisis.",
    category: "Saving",
    date: "2026-05-04",
    readTime: "5 min read",
    content: [
      "An emergency fund is for the things you can't see coming. A sinking fund is for the things you absolutely can — you just haven't written them down yet.",
      "Holiday spending happens every December. Car maintenance happens every year. Annual subscriptions renew on a schedule. None of these are emergencies, but treated as one-off surprises, they'll quietly wreck an otherwise solid budget.",
      "Open a separate savings account — or use named 'buckets' inside one account — and list every irregular expense you can predict over the next twelve months, along with a rough cost. Divide each by twelve and set that amount aside monthly. A $600 December gift budget becomes a $50 monthly transfer that nobody notices leaving.",
      "The categories worth starting with: car maintenance, gifts, annual subscriptions or memberships, home or appliance repairs, and travel. Add more as you notice which 'surprises' keep repeating year after year.",
      "The quiet benefit of sinking funds isn't just avoiding debt when the expense hits — it's removing the dread. When the money's already there, a flat tire is an errand, not an emergency.",
    ],
  },
  {
    slug: "high-yield-savings-account-actually-matters",
    title: "Why Your Savings Account Interest Rate Actually Matters",
    excerpt:
      "The difference between a 0.01% and a 4%+ savings rate on $10,000 is real money, sitting there doing nothing, in an account most people forget to check.",
    category: "Saving",
    date: "2026-04-20",
    readTime: "5 min read",
    content: [
      "A traditional savings account at a big bank has, for years, paid close to nothing — often a fraction of a percent. High-yield savings accounts, mostly offered by online banks, pay meaningfully more, because they carry lower overhead and compete harder for deposits.",
      "On $10,000 sitting for a year, the gap between a near-zero rate and a strong high-yield rate is the difference between a few dollars and several hundred. That's money earned by moving funds, not by earning more or cutting spending.",
      "The trade-off is usually minor: no physical branch, and sometimes a slightly slower transfer time to move money to a checking account. For an emergency fund or a sinking fund that isn't meant to be touched daily, that trade-off is easy to accept.",
      "Look for FDIC insurance (or NCUA for credit unions), no monthly fees, no minimum balance requirements, and easy transfers to your existing checking account. Rates change with broader interest rate conditions, so it's worth comparing options every year or two rather than assuming the account you opened once is still the best one available.",
    ],
  },
  {
    slug: "freelance-writing-first-client-in-30-days",
    title: "Landing Your First Freelance Writing Client in 30 Days",
    excerpt:
      "You don't need a portfolio full of published work to start freelance writing. You need three good samples, one clear niche, and a plan to pitch consistently.",
    category: "Making Money Online",
    date: "2026-04-06",
    readTime: "8 min read",
    featured: true,
    content: [
      "The biggest myth in freelance writing is that you need experience before anyone will pay you. What clients actually need is proof you can write clearly about something relevant to them — and that proof doesn't require a byline.",
      "Week one: pick a niche and write three samples. A niche isn't a cage, it's a shortcut — 'personal finance for beginners' or 'B2B software explainers' tells a potential client exactly what you're good for. Write three genuinely strong pieces in that niche, even unpublished, and host them somewhere simple and free.",
      "Week two: build a one-page portfolio site and a short pitch template. The pitch should name the publication or company by name, reference something specific about their recent content, and propose one concrete article idea rather than asking generically 'do you accept freelance writers.'",
      "Weeks three and four: send five pitches a day, five days a week. Most won't get a reply, and that's normal, not a signal to stop. Freelance writing income comes from volume of outreach early on, before referrals start doing the work for you.",
      "Price from the start as if you intend to keep doing this. A too-low rate is harder to raise later than to start higher and negotiate down occasionally. Per-word rates are common for beginners, but as soon as you have two or three regular clients, shift toward flat project rates — they reward getting faster instead of punishing it.",
      "Thirty days is enough time for a genuinely committed pitching schedule to land a first paying client. It is rarely enough time to land a client while only pitching occasionally, so the daily habit matters more than any single pitch.",
    ],
  },
  {
    slug: "selling-digital-products-no-audience",
    title: "Selling Digital Products When You Don't Have an Audience Yet",
    excerpt:
      "You don't need 100,000 followers to sell a $19 template. You need one specific problem, solved well, sold to the smallest group of people who actually have that problem.",
    category: "Making Money Online",
    date: "2026-03-22",
    readTime: "7 min read",
    content: [
      "Most advice about digital products starts with 'build an audience first.' That's true for some formats, but it skips a faster path: solving one specific, narrow problem so well that the product sells itself into existing communities, even a small one.",
      "Start narrower than feels comfortable. Not 'a budgeting template' — a budgeting template for freelance graphic designers with irregular monthly income. The narrower the promise, the easier it is to describe in one sentence, and the easier it is for the right person to recognize it as exactly what they need.",
      "Validate before building the full version. A single landing page describing the product, with a waitlist or a 'buy now' button that leads to a 'coming soon' page, tells you in days — not months — whether the idea has real demand, before you spend a weekend building it.",
      "Distribution without an audience usually means borrowing someone else's: relevant subreddits, niche Facebook groups, Discord communities, or forums where your exact customer already asks this exact question. Answer the question well, genuinely, and mention the product only where it's actually the answer.",
      "Price higher than instinct suggests for a first digital product. A $9 price point has to sell in huge volume to matter; a well-targeted $39–$79 product needs far fewer buyers to be worth the time it took to build.",
    ],
  },
  {
    slug: "side-hustles-under-five-hours-a-week",
    title: "Side Hustles That Actually Fit in Five Hours a Week",
    excerpt:
      "Not every side hustle needs to become a second job. These are built for people with a full-time job, a family, and a genuinely limited number of free evenings.",
    category: "Side Hustles",
    date: "2026-03-08",
    readTime: "6 min read",
    content: [
      "The side hustles that get the most attention online — content creation, dropshipping, agency work — often demand ten to twenty hours a week to show real income. For someone with a full-time job and a life outside it, that's not realistic, and starting one anyway is a fast way to quit within a month.",
      "Local services scale down well. Pet sitting, tutoring in a subject you already know, or basic handyman work can be booked in two or three appointment blocks a week, at a rate you set, with no ongoing content or marketing treadmill required.",
      "Selling skills you already use at work, just for someone else's smaller project, is often faster to start than anything built from scratch. A spreadsheet builder, a basic website fixer, a resume editor — these are services people actively search for, priced per project rather than per hour.",
      "Resale and flipping, done narrowly, fits well into a few hours: one category (furniture, sneakers, tools), one weekend sourcing trip, and listings written once and left to sell during the week.",
      "The honest filter for a five-hour side hustle: could you do the entire thing, start to finish, in two sessions this week, without it needing your attention the other five days? If not, it's a good idea for a different season of life, not for this one.",
    ],
  },
  {
    slug: "should-you-turn-your-side-hustle-into-a-business",
    title: "Should You Turn Your Side Hustle Into a Real Business?",
    excerpt:
      "There's a real difference between a side hustle that pays for vacations and a business that could replace your income. Here's how to tell which one you're building.",
    category: "Side Hustles",
    date: "2026-02-14",
    readTime: "6 min read",
    content: [
      "Plenty of side hustles are, and should stay, exactly what they are: extra income that doesn't need a business plan, an LLC, or a five-year vision. The question worth asking isn't 'is this successful,' it's 'do I actually want more of this.'",
      "A useful test is whether the income is repeatable without you doing something new each time. A side hustle you have to reinvent every month — a new product, a new client type, a new platform — is a hobby with income, which is fine, but it's not yet a scalable business.",
      "Look at margin, not just revenue. A side hustle bringing in $800 a month that costs $600 in materials and platform fees is a very different opportunity than one bringing in $800 with $50 in costs. The second has room to grow into something bigger; the first may be close to its ceiling already.",
      "Before formalizing anything — registering a business, opening a business bank account, hiring — get three consecutive months of consistent income and demand at the current, informal scale. Consistency is the signal that's actually worth acting on, not a single great month.",
      "If it passes those checks and it's still something you want more of, that's the point to treat it like a business: separate finances, a real pricing structure, and a decision about how many hours a week you're willing to give it before it has to earn its place against your day job.",
    ],
  },
];

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find((p) => p.slug === slug);
}

export function getPostsByCategory(category?: Category): Post[] {
  if (!category) return posts;
  return posts.filter((p) => p.category === category);
}

export function getFeaturedPosts(): Post[] {
  return posts.filter((p) => p.featured);
}

export function getRelatedPosts(current: Post, limit = 2): Post[] {
  return posts
    .filter((p) => p.slug !== current.slug && p.category === current.category)
    .slice(0, limit);
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

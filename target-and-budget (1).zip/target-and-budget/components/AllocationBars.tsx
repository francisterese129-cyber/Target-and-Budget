import type { CSSProperties } from "react";

const rows: { label: string; percent: number; color: string }[] = [
  { label: "Needs", percent: 50, color: "bg-sage-700" },
  { label: "Wants", percent: 30, color: "bg-sage-400" },
  { label: "Savings & Goals", percent: 20, color: "bg-gold-500" },
];

export default function AllocationBars() {
  return (
    <div
      className="w-full max-w-sm rounded-2xl border border-sage-200 bg-paper p-6 shadow-[0_20px_60px_-25px_rgba(33,45,30,0.35)]"
      role="img"
      aria-label="Sample budget split: 50 percent needs, 30 percent wants, 20 percent savings"
    >
      <div className="flex items-center justify-between">
        <p className="font-body text-xs font-medium uppercase tracking-wider text-sage-500">
          This month&apos;s split
        </p>
        <p className="font-heading text-sm text-sage-400">Sample</p>
      </div>

      <div className="mt-5 space-y-5">
        {rows.map((row, i) => (
          <div key={row.label}>
            <div className="mb-1.5 flex items-baseline justify-between font-body text-sm">
              <span className="text-sage-700">{row.label}</span>
              <span className="font-heading text-lg font-semibold text-sage-900">
                {row.percent}%
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-sage-100">
              <div
                className={`balance-fill h-full rounded-full ${row.color}`}
                style={
                  {
                    "--fill-to": `${row.percent}%`,
                    animationDelay: `${i * 150 + 200}ms`,
                    width: 0,
                  } as CSSProperties
                }
              />
            </div>
          </div>
        ))}
      </div>

      <p className="ledger-rule mt-6 pb-2 font-body text-xs text-sage-500">
        Based on the classic 50/30/20 framework
      </p>
    </div>
  );
}

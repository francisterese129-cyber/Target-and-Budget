import Link from "next/link";
import type { Post } from "@/lib/posts";
import { formatDate } from "@/lib/posts";

const categoryColor: Record<string, string> = {
  Budgeting: "bg-sage-100 text-sage-800",
  Saving: "bg-gold-400/20 text-gold-600",
  "Making Money Online": "bg-sage-200 text-sage-800",
  "Side Hustles": "bg-sage-700 text-cream",
};

export default function PostCard({ post, index }: { post: Post; index?: number }) {
  return (
    <article className="group relative flex h-full flex-col rounded-xl border border-sage-200 bg-paper p-6 transition-shadow hover:shadow-[0_8px_30px_-12px_rgba(33,45,30,0.25)]">
      <div className="flex items-center gap-3">
        {typeof index === "number" && (
          <span className="font-heading text-sm text-sage-400">
            {String(index + 1).padStart(2, "0")}
          </span>
        )}
        <span
          className={`rounded-full px-3 py-1 font-body text-[11px] font-medium uppercase tracking-wider ${
            categoryColor[post.category] ?? "bg-sage-100 text-sage-800"
          }`}
        >
          {post.category}
        </span>
      </div>

      <h3 className="mt-4 font-heading text-2xl font-semibold leading-snug text-sage-900">
        <Link
          href={`/blog/${post.slug}`}
          className="after:absolute after:inset-0 hover:text-sage-700"
        >
          {post.title}
        </Link>
      </h3>

      <p className="mt-3 flex-1 font-body text-[15px] leading-relaxed text-sage-600">
        {post.excerpt}
      </p>

      <div className="mt-5 flex items-center gap-3 font-body text-xs text-sage-500">
        <time dateTime={post.date}>{formatDate(post.date)}</time>
        <span aria-hidden="true">·</span>
        <span>{post.readTime}</span>
      </div>
    </article>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const links = [
  { href: "/", label: "Home" },
  { href: "/blog", label: "Blog" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-50 border-b border-sage-200 bg-cream/90 backdrop-blur">
      <div className="mx-auto flex max-w-wrap items-center justify-between px-6 py-4 sm:px-8">
        <Link
          href="/"
          className="group flex items-center gap-2.5"
          aria-label="Target & Budget, home"
        >
          <TargetMark />
          <span className="font-heading text-2xl font-semibold tracking-tight text-sage-900">
            Target <span className="text-gold-500">&amp;</span> Budget
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {links.map((link) => {
            const active =
              link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`font-body text-[15px] tracking-wide transition-colors ${
                  active
                    ? "text-sage-900 font-medium"
                    : "text-sage-600 hover:text-sage-900"
                }`}
                aria-current={active ? "page" : undefined}
              >
                {link.label}
              </Link>
            );
          })}
          <Link
            href="/blog"
            className="rounded-full bg-sage-700 px-5 py-2 font-body text-sm font-medium text-cream transition-colors hover:bg-sage-800"
          >
            Start Reading
          </Link>
        </nav>

        <button
          type="button"
          className="flex items-center gap-2 rounded-md p-2 text-sage-800 md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="sr-only">Menu</span>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            {open ? (
              <path
                d="M6 6l12 12M18 6L6 18"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            ) : (
              <path
                d="M4 7h16M4 12h16M4 17h16"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            )}
          </svg>
        </button>
      </div>

      {open && (
        <nav
          id="mobile-menu"
          aria-label="Mobile"
          className="border-t border-sage-200 bg-cream px-6 py-4 md:hidden"
        >
          <ul className="flex flex-col gap-1">
            {links.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="block rounded-md px-2 py-3 font-body text-base text-sage-800 hover:bg-sage-50"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

function TargetMark() {
  return (
    <svg
      width="30"
      height="30"
      viewBox="0 0 30 30"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <circle cx="15" cy="15" r="13" stroke="#43573E" strokeWidth="2" />
      <circle cx="15" cy="15" r="8.5" stroke="#6B8862" strokeWidth="2" />
      <circle cx="15" cy="15" r="4" fill="#B58A4A" />
    </svg>
  );
}

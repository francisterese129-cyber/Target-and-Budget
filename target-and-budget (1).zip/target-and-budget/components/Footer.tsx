import Link from "next/link";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-sage-200 bg-sage-900 text-sage-100">
      <div className="mx-auto max-w-wrap px-6 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <svg width="26" height="26" viewBox="0 0 30 30" fill="none" aria-hidden="true">
                <circle cx="15" cy="15" r="13" stroke="#C8D5BE" strokeWidth="2" />
                <circle cx="15" cy="15" r="8.5" stroke="#A9BC9C" strokeWidth="2" />
                <circle cx="15" cy="15" r="4" fill="#C9A46A" />
              </svg>
              <span className="font-heading text-xl font-semibold text-cream">
                Target &amp; Budget
              </span>
            </div>
            <p className="mt-4 max-w-sm font-body text-sm leading-relaxed text-sage-300">
              Plain-spoken guidance on budgeting, saving, and earning more —
              written for people building their financial plan around real,
              imperfect life.
            </p>
          </div>

          <div>
            <h3 className="font-body text-sm font-semibold uppercase tracking-wider text-sage-400">
              Explore
            </h3>
            <ul className="mt-4 space-y-2.5 font-body text-sm text-sage-200">
              <li>
                <Link href="/" className="hover:text-cream">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/blog" className="hover:text-cream">
                  Blog Posts
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-cream">
                  About Me
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-cream">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-body text-sm font-semibold uppercase tracking-wider text-sage-400">
              Topics
            </h3>
            <ul className="mt-4 space-y-2.5 font-body text-sm text-sage-200">
              <li>
                <Link href="/blog?category=Budgeting" className="hover:text-cream">
                  Budgeting
                </Link>
              </li>
              <li>
                <Link href="/blog?category=Saving" className="hover:text-cream">
                  Saving
                </Link>
              </li>
              <li>
                <Link href="/blog?category=Making+Money+Online" className="hover:text-cream">
                  Making Money Online
                </Link>
              </li>
              <li>
                <Link href="/blog?category=Side+Hustles" className="hover:text-cream">
                  Side Hustles
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-sage-800 pt-6 font-body text-xs text-sage-400 sm:flex-row sm:items-center sm:justify-between">
          <p>© {year} Target &amp; Budget. All rights reserved.</p>
          <div className="flex items-center gap-5">
            <Link href="/privacy-policy" className="hover:text-cream">
              Privacy Policy
            </Link>
            <span aria-hidden="true">·</span>
            <p>Not financial advice — just what&apos;s worked for us.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

"use client";

import { useState, type FormEvent } from "react";

export default function Newsletter() {
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [email, setEmail] = useState("");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    try {
      await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "newsletter", email }),
      });
    } catch {
      // Non-fatal for this demo form — see README for wiring up a real provider.
    }
    setStatus("done");
  }

  return (
    <section className="rounded-2xl bg-sage-800 px-6 py-12 text-center sm:px-12">
      <p className="font-body text-xs font-medium uppercase tracking-[0.2em] text-gold-400">
        Weekly, no fluff
      </p>
      <h2 className="mx-auto mt-3 max-w-md font-heading text-3xl font-semibold text-cream">
        One useful money idea in your inbox each week
      </h2>
      <p className="mx-auto mt-3 max-w-sm font-body text-sm text-sage-200">
        Budgeting tactics, saving strategies, and honest side-hustle math.
        Unsubscribe any time.
      </p>

      {status === "done" ? (
        <p className="mx-auto mt-6 max-w-sm font-body text-sm text-gold-400">
          You&apos;re on the list — check your inbox to confirm.
        </p>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="mx-auto mt-6 flex max-w-md flex-col gap-3 sm:flex-row"
        >
          <label htmlFor="newsletter-email" className="sr-only">
            Email address
          </label>
          <input
            id="newsletter-email"
            type="email"
            required
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-full border border-sage-600 bg-sage-900/40 px-5 py-3 font-body text-sm text-cream placeholder:text-sage-400 focus:border-gold-400"
          />
          <button
            type="submit"
            disabled={status === "loading"}
            className="shrink-0 rounded-full bg-gold-500 px-6 py-3 font-body text-sm font-semibold text-sage-900 transition-colors hover:bg-gold-400 disabled:opacity-60"
          >
            {status === "loading" ? "Joining…" : "Subscribe"}
          </button>
        </form>
      )}
    </section>
  );
}

import Link from "next/link";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { categories, getPostsByCategory, type Category } from "@/lib/posts";

export const metadata: Metadata = {
  title: "Blog Posts",
  description:
    "Every article on Target & Budget — budgeting systems, saving strategies, side hustles, and ways to make money online.",
};

function isCategory(value: string | undefined): value is Category {
  return !!value && (categories as string[]).includes(value);
}

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const params = await searchParams;
  const activeCategory = isCategory(params.category) ? params.category : undefined;
  const filteredPosts = getPostsByCategory(activeCategory)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <div className="mx-auto max-w-wrap px-6 py-16 sm:px-8 sm:py-20">
      <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
        The archive
      </p>
      <h1 className="mt-3 font-heading text-5xl font-semibold text-sage-900">
        Blog Posts
      </h1>
      <p className="mt-4 max-w-xl font-body text-lg text-sage-700">
        {filteredPosts.length} {filteredPosts.length === 1 ? "post" : "posts"}
        {activeCategory ? ` in ${activeCategory}` : ""} — sorted newest first.
      </p>

      <div className="mt-8 flex flex-wrap gap-2.5" role="list" aria-label="Filter by category">
        <Link
          href="/blog"
          className={`rounded-full border px-4 py-2 font-body text-sm font-medium transition-colors ${
            !activeCategory
              ? "border-sage-700 bg-sage-700 text-cream"
              : "border-sage-300 text-sage-700 hover:border-sage-500"
          }`}
        >
          All posts
        </Link>
        {categories.map((cat) => (
          <Link
            key={cat}
            href={`/blog?category=${encodeURIComponent(cat)}`}
            className={`rounded-full border px-4 py-2 font-body text-sm font-medium transition-colors ${
              activeCategory === cat
                ? "border-sage-700 bg-sage-700 text-cream"
                : "border-sage-300 text-sage-700 hover:border-sage-500"
            }`}
          >
            {cat}
          </Link>
        ))}
      </div>

      {filteredPosts.length > 0 ? (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredPosts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      ) : (
        <div className="mt-14 rounded-xl border border-dashed border-sage-300 p-12 text-center">
          <p className="font-heading text-2xl text-sage-800">
            No posts in this category yet
          </p>
          <p className="mt-2 font-body text-sage-600">
            Check back soon, or browse everything we&apos;ve published so far.
          </p>
          <Link
            href="/blog"
            className="mt-5 inline-block rounded-full bg-sage-700 px-5 py-2.5 font-body text-sm font-medium text-cream hover:bg-sage-800"
          >
            View all posts
          </Link>
        </div>
      )}
    </div>
  );
}

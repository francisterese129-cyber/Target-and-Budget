import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import PostCard from "@/components/PostCard";
import Newsletter from "@/components/Newsletter";
import { formatDate, getPostBySlug, getRelatedPosts, posts } from "@/lib/posts";

export function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) return {};

  return {
    title: post.title,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: post.date,
    },
  };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) notFound();

  const related = getRelatedPosts(post);

  return (
    <article className="mx-auto max-w-prose px-6 py-16 sm:px-8 sm:py-20">
      <Link
        href="/blog"
        className="font-body text-sm font-medium text-sage-600 hover:text-sage-900"
      >
        ← All posts
      </Link>

      <p className="mt-6 font-body text-xs font-semibold uppercase tracking-[0.2em] text-gold-600">
        {post.category}
      </p>
      <h1 className="mt-3 font-heading text-4xl font-semibold leading-tight text-sage-900 sm:text-5xl">
        {post.title}
      </h1>
      <div className="mt-4 flex items-center gap-3 font-body text-sm text-sage-500">
        <time dateTime={post.date}>{formatDate(post.date)}</time>
        <span aria-hidden="true">·</span>
        <span>{post.readTime}</span>
      </div>

      <div className="mt-10 space-y-6 font-body text-[17px] leading-[1.8] text-ink">
        {post.content.map((paragraph, i) => (
          <p key={i}>{paragraph}</p>
        ))}
      </div>

      <div className="mt-12 rounded-xl border border-sage-200 bg-sage-50 p-6">
        <p className="font-body text-sm leading-relaxed text-sage-700">
          <strong className="text-sage-900">A quick note:</strong> this article
          shares general information, not personalized financial advice. Your
          situation is your own — when in doubt, talk it through with a
          licensed financial professional.
        </p>
      </div>

      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="font-heading text-2xl font-semibold text-sage-900">
            More on {post.category}
          </h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            {related.map((r) => (
              <PostCard key={r.slug} post={r} />
            ))}
          </div>
        </div>
      )}

      <div className="mt-16">
        <Newsletter />
      </div>
    </article>
  );
}

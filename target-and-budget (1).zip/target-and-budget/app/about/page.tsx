import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Me",
  description:
    "The story behind Target & Budget, and why it's built around real, imperfect budgets rather than spreadsheet perfection.",
};

const milestones = [
  {
    year: "2019",
    text: "Paid off the last of a five-figure credit card balance using a version of the zero-based budget shared on this site.",
  },
  {
    year: "2021",
    text: "Started freelance writing on the side, replacing a full month's rent within the first year.",
  },
  {
    year: "2023",
    text: "Left the day job to write and consult on personal finance full-time.",
  },
  {
    year: "2026",
    text: "Still tracking every dollar in the same spreadsheet, now shared with over a thousand readers.",
  },
];

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-wrap px-6 py-16 sm:px-8 sm:py-20">
      <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:gap-16">
        <div>
          <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
            About
          </p>
          <h1 className="mt-3 font-heading text-5xl font-semibold text-sage-900">
            Hi — I&apos;m glad you&apos;re here.
          </h1>
          <div className="mt-6 space-y-5 font-body text-[17px] leading-[1.8] text-sage-700">
            <p>
              Target &amp; Budget started as a personal spreadsheet, not a
              blog. I built it to climb out of credit card debt after a few
              years of good income and no real plan for it — the classic gap
              between what you earn and what you keep.
            </p>
            <p>
              What actually worked wasn&apos;t a stricter budget. It was a
              simpler one: fewer categories, a real buffer for the
              unexpected, and a weekly ten-minute check-in instead of a
              monthly overhaul. That system, and the side income that came
              from writing about it, eventually became this site.
            </p>
            <p>
              I write about three things: budgeting systems that survive
              real life, saving strategies that don&apos;t require
              white-knuckle discipline, and the honest math behind making
              extra money — whether that&apos;s a side hustle on weekends or
              freelance work that replaces a paycheck entirely.
            </p>
            <p>
              Nothing here is generic advice recycled from somewhere else.
              Every framework has been tested against my own budget first,
              adjusted until it actually held, and only then written up.
            </p>
          </div>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              href="/blog"
              className="rounded-full bg-sage-700 px-6 py-3 font-body text-sm font-medium text-cream hover:bg-sage-800"
            >
              Read the blog
            </Link>
            <Link
              href="/contact"
              className="rounded-full border border-sage-400 px-6 py-3 font-body text-sm font-medium text-sage-800 hover:border-sage-600"
            >
              Get in touch
            </Link>
          </div>
        </div>

        <div>
          <div className="rounded-2xl border border-sage-200 bg-sage-50 p-8">
            <h2 className="font-heading text-2xl font-semibold text-sage-900">
              A rough timeline
            </h2>
            <ol className="mt-6 space-y-6 border-l border-sage-300 pl-6">
              {milestones.map((m) => (
                <li key={m.year} className="relative">
                  <span className="absolute -left-[31px] top-1 h-3 w-3 rounded-full border-2 border-cream bg-sage-600" />
                  <p className="font-heading text-lg font-semibold text-sage-800">
                    {m.year}
                  </p>
                  <p className="mt-1 font-body text-sm leading-relaxed text-sage-600">
                    {m.text}
                  </p>
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-6 rounded-2xl border border-sage-200 bg-paper p-8">
            <h2 className="font-heading text-2xl font-semibold text-sage-900">
              What this site is not
            </h2>
            <ul className="mt-4 space-y-3 font-body text-sm leading-relaxed text-sage-600">
              <li>
                Not personalized financial, tax, or investment advice — just
                what&apos;s worked here, shared honestly.
              </li>
              <li>
                Not a &quot;get rich quick&quot; feed. Side hustle math is
                shown with real time and margin, not best-case fantasy
                numbers.
              </li>
              <li>
                Not sponsored by a bank or app pretending to be neutral
                editorial content.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

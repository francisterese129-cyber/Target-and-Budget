import { NextResponse } from "next/server";

// This route accepts both the contact form and the newsletter signup form.
// It validates input and returns a success response, but does not yet send
// email or store submissions anywhere — wire up a provider (Resend, Postmark,
// a database, a Google Sheet, ConvertKit, etc.) before relying on this in
// production. See README.md for suggested next steps.

export async function POST(request: Request) {
  let body: Record<string, unknown>;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const email = typeof body.email === "string" ? body.email.trim() : "";
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!email || !emailPattern.test(email)) {
    return NextResponse.json({ error: "A valid email address is required." }, { status: 400 });
  }

  if (body.type === "newsletter") {
    // TODO: add `email` to your email marketing provider.
    return NextResponse.json({ ok: true });
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const message = typeof body.message === "string" ? body.message.trim() : "";

  if (!name || !message) {
    return NextResponse.json(
      { error: "Name and message are required." },
      { status: 400 }
    );
  }

  // TODO: send `{ name, email, message }` via your email provider of choice.

  return NextResponse.json({ ok: true });
}

import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-wrap flex-col items-center px-6 py-28 text-center sm:px-8">
      <svg width="56" height="56" viewBox="0 0 30 30" fill="none" aria-hidden="true">
        <circle cx="15" cy="15" r="13" stroke="#C8D5BE" strokeWidth="2" />
        <circle cx="15" cy="15" r="8.5" stroke="#87A177" strokeWidth="2" />
        <circle cx="15" cy="15" r="4" fill="#B58A4A" />
      </svg>
      <p className="mt-6 font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
        404
      </p>
      <h1 className="mt-2 font-heading text-4xl font-semibold text-sage-900">
        Missed the target
      </h1>
      <p className="mt-3 max-w-sm font-body text-sage-600">
        That page doesn&apos;t exist, or has moved. Let&apos;s get you back on
        budget.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-full bg-sage-700 px-6 py-3 font-body text-sm font-medium text-cream hover:bg-sage-800"
      >
        Back to home
      </Link>
    </div>
  );
}

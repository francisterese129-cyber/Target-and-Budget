import type { Metadata } from "next";
import ContactForm from "./ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Questions, story ideas, or collaboration requests — get in touch with Target & Budget.",
};

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-wrap px-6 py-16 sm:px-8 sm:py-20">
      <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
            Get in touch
          </p>
          <h1 className="mt-3 font-heading text-5xl font-semibold text-sage-900">
            Let&apos;s talk money
          </h1>
          <p className="mt-5 font-body text-lg leading-relaxed text-sage-700">
            Have a question about a post, a topic you&apos;d like covered, or
            a partnership idea? Send a note — every message is read
            personally.
          </p>

          <div className="mt-8 space-y-6">
            <div>
              <h2 className="font-heading text-lg font-semibold text-sage-900">
                Best for
              </h2>
              <ul className="mt-2 space-y-1.5 font-body text-sm text-sage-600">
                <li>Reader questions and topic requests</li>
                <li>Corrections or feedback on a post</li>
                <li>Media, partnership, and sponsorship inquiries</li>
              </ul>
            </div>
            <div>
              <h2 className="font-heading text-lg font-semibold text-sage-900">
                Response time
              </h2>
              <p className="mt-2 font-body text-sm text-sage-600">
                Usually within two to three business days.
              </p>
            </div>
          </div>
        </div>

        <ContactForm />
      </div>
    </div>
  );
}

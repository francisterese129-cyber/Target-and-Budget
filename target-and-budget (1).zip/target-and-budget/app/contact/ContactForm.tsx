"use client";

import { useState, type FormEvent } from "react";

type Status = "idle" | "loading" | "success" | "error";

export default function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = {
      name: String(data.get("name") ?? ""),
      email: String(data.get("email") ?? ""),
      message: String(data.get("message") ?? ""),
    };

    setStatus("loading");
    setErrorMsg("");

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setErrorMsg(body.error ?? "Something went wrong. Please try again.");
        setStatus("error");
        return;
      }

      setStatus("success");
      form.reset();
    } catch {
      setErrorMsg("Couldn't send that — check your connection and try again.");
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="rounded-2xl border border-sage-200 bg-sage-50 p-10 text-center">
        <p className="font-heading text-2xl font-semibold text-sage-900">
          Message sent
        </p>
        <p className="mt-2 font-body text-sage-600">
          Thanks for reaching out — you&apos;ll hear back within a few
          business days.
        </p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="mt-6 font-body text-sm font-medium text-sage-700 underline underline-offset-4 hover:text-sage-900"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-2xl border border-sage-200 bg-paper p-8"
      noValidate
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="font-body text-sm font-medium text-sage-800">
            Name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            required
            autoComplete="name"
            className="mt-1.5 w-full rounded-lg border border-sage-300 bg-cream px-4 py-2.5 font-body text-sm text-ink placeholder:text-sage-400 focus:border-sage-600"
            placeholder="Jane Doe"
          />
        </div>
        <div>
          <label htmlFor="email" className="font-body text-sm font-medium text-sage-800">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="email"
            className="mt-1.5 w-full rounded-lg border border-sage-300 bg-cream px-4 py-2.5 font-body text-sm text-ink placeholder:text-sage-400 focus:border-sage-600"
            placeholder="you@example.com"
          />
        </div>
      </div>

      <div className="mt-5">
        <label htmlFor="message" className="font-body text-sm font-medium text-sage-800">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={6}
          className="mt-1.5 w-full resize-y rounded-lg border border-sage-300 bg-cream px-4 py-2.5 font-body text-sm text-ink placeholder:text-sage-400 focus:border-sage-600"
          placeholder="What's on your mind?"
        />
      </div>

      {status === "error" && (
        <p role="alert" className="mt-4 font-body text-sm text-red-700">
          {errorMsg}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "loading"}
        className="mt-6 w-full rounded-full bg-sage-700 px-6 py-3.5 font-body text-sm font-semibold text-cream transition-colors hover:bg-sage-800 disabled:opacity-60 sm:w-auto"
      >
        {status === "loading" ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}

import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Target & Budget collects, uses, and protects your information.",
};

const sections: { heading: string; body: string[] }[] = [
  {
    heading: "1. Overview",
    body: [
      "This Privacy Policy explains how Target & Budget (\"we,\" \"us,\" or \"our\") collects, uses, and protects information when you visit targetandbudget.com (the \"Site\") or subscribe to our newsletter. Replace the placeholder details in this template — business name, contact email, and any third-party tools — with your own before publishing.",
    ],
  },
  {
    heading: "2. Information We Collect",
    body: [
      "Information you provide directly: your name and email address when you subscribe to the newsletter, and your name, email address, and message when you submit the contact form.",
      "Information collected automatically: standard technical data such as browser type, device type, pages visited, and referring URLs, typically collected through analytics tools.",
      "We do not knowingly collect sensitive financial account information, such as bank login credentials or full payment card numbers, through this Site.",
    ],
  },
  {
    heading: "3. How We Use Information",
    body: [
      "To send the newsletter and respond to contact form submissions.",
      "To understand how visitors use the Site, so we can improve content and site performance.",
      "To maintain the security of the Site and prevent misuse.",
      "We do not sell personal information to third parties.",
    ],
  },
  {
    heading: "4. Cookies and Analytics",
    body: [
      "The Site may use cookies or similar technologies for basic functionality and, if enabled, analytics tools (such as Google Analytics) to understand traffic patterns. You can disable cookies through your browser settings; some site features may not function as intended if you do.",
    ],
  },
  {
    heading: "5. Third-Party Services",
    body: [
      "We may use third-party services to operate the Site, such as an email newsletter provider, form-handling or email-delivery service, and web hosting or analytics providers. These providers process data according to their own privacy policies, and we select providers that take reasonable steps to protect user data.",
      "If this Site includes affiliate links (for example, to financial products or tools mentioned in a post), clicking those links may share limited data, such as a referral code, with the third-party site. Affiliate relationships, where present, will be disclosed within the relevant post.",
    ],
  },
  {
    heading: "6. Data Retention",
    body: [
      "Newsletter subscriber information is retained until you unsubscribe. Contact form submissions are retained only as long as needed to respond to and resolve your inquiry, unless a longer period is required by law.",
    ],
  },
  {
    heading: "7. Your Choices and Rights",
    body: [
      "You can unsubscribe from the newsletter at any time using the link included in every email.",
      "Depending on your location, you may have rights to access, correct, or delete personal information we hold about you. To make a request, contact us using the details in Section 9.",
    ],
  },
  {
    heading: "8. Children's Privacy",
    body: [
      "This Site is not directed to children under 13, and we do not knowingly collect personal information from children under 13.",
    ],
  },
  {
    heading: "9. Contact Us",
    body: [
      "For questions about this Privacy Policy or to exercise your data rights, use the contact form on this Site, or email hello@targetandbudget.com (replace with your real contact address before publishing).",
    ],
  },
  {
    heading: "10. Changes to This Policy",
    body: [
      "We may update this Privacy Policy from time to time. The \"Last updated\" date below reflects the most recent revision. Continued use of the Site after changes take effect constitutes acceptance of the updated policy.",
    ],
  },
];

export default function PrivacyPolicyPage() {
  return (
    <div className="mx-auto max-w-prose px-6 py-16 sm:px-8 sm:py-20">
      <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
        Legal
      </p>
      <h1 className="mt-3 font-heading text-5xl font-semibold text-sage-900">
        Privacy Policy
      </h1>
      <p className="mt-3 font-body text-sm text-sage-500">
        Last updated: July 26, 2026
      </p>

      <div className="mt-6 rounded-xl border border-gold-500/30 bg-gold-400/10 p-5">
        <p className="font-body text-sm leading-relaxed text-sage-800">
          <strong>Template notice:</strong> this policy is a starting point,
          not legal advice. Update the placeholders (business name, contact
          email, tools used) and, if you handle EU/UK visitors or collect
          sensitive data, have it reviewed by a qualified professional before
          publishing.
        </p>
      </div>

      <div className="mt-10 space-y-10">
        {sections.map((section) => (
          <section key={section.heading}>
            <h2 className="font-heading text-2xl font-semibold text-sage-900">
              {section.heading}
            </h2>
            <div className="mt-3 space-y-3 font-body text-[15px] leading-[1.8] text-sage-700">
              {section.body.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

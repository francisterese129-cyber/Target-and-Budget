import Link from "next/link";
import AllocationBars from "@/components/AllocationBars";
import PostCard from "@/components/PostCard";
import Newsletter from "@/components/Newsletter";
import { categories, getFeaturedPosts, posts } from "@/lib/posts";

const categoryCopy: Record<string, string> = {
  Budgeting: "Systems and frameworks for telling your money where to go.",
  Saving: "Building a cushion — and making it grow — without white-knuckling it.",
  "Making Money Online": "Freelancing, digital products, and honest income math.",
  "Side Hustles": "Extra income that actually fits around a full-time life.",
};

export default function HomePage() {
  const featured = getFeaturedPosts();
  const recent = posts
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .slice(0, 6);

  return (
    <>
      {/* Hero */}
      <section className="receipt-edge relative overflow-hidden border-b border-sage-200 bg-sage-50 pb-16 pt-16 sm:pb-24 sm:pt-20">
        <div className="mx-auto grid max-w-wrap items-center gap-12 px-6 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-8">
          <div className="animate-rise opacity-0">
            <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-sage-600">
              Budgeting · Saving · Earning
            </p>
            <h1 className="mt-4 font-heading text-5xl font-semibold leading-[1.05] text-sage-900 sm:text-6xl">
              Set the target.
              <br />
              Build the budget.
            </h1>
            <p className="mt-6 max-w-lg font-body text-lg leading-relaxed text-sage-700">
              Plain-spoken money guidance for real budgets, real side hustles,
              and real income that doesn&apos;t arrive the same way every
              month. No jargon, no shame — just a plan you can actually keep.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                href="/blog"
                className="rounded-full bg-sage-700 px-7 py-3.5 font-body text-sm font-semibold text-cream transition-colors hover:bg-sage-800"
              >
                Read the blog
              </Link>
              <Link
                href="/about"
                className="font-body text-sm font-semibold text-sage-800 underline decoration-sage-400 underline-offset-4 hover:text-sage-900"
              >
                Meet the writer
              </Link>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end">
            <AllocationBars />
          </div>
        </div>
      </section>

      {/* Category overview */}
      <section className="mx-auto max-w-wrap px-6 py-16 sm:px-8 sm:py-20">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-heading text-3xl font-semibold text-sage-900 sm:text-4xl">
            Four ways to move the needle
          </h2>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((cat) => (
            <Link
              key={cat}
              href={`/blog?category=${encodeURIComponent(cat)}`}
              className="group rounded-xl border border-sage-200 bg-paper p-6 transition-colors hover:border-sage-400"
            >
              <h3 className="font-heading text-xl font-semibold text-sage-900 group-hover:text-sage-700">
                {cat}
              </h3>
              <p className="mt-2 font-body text-sm leading-relaxed text-sage-600">
                {categoryCopy[cat]}
              </p>
              <span className="mt-4 inline-block font-body text-sm font-medium text-gold-600">
                Browse posts →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured posts */}
      {featured.length > 0 && (
        <section className="border-y border-sage-200 bg-sage-50 py-16 sm:py-20">
          <div className="mx-auto max-w-wrap px-6 sm:px-8">
            <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-gold-600">
              Start here
            </p>
            <h2 className="mt-2 font-heading text-3xl font-semibold text-sage-900 sm:text-4xl">
              Reader favorites
            </h2>
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              {featured.map((post, i) => (
                <PostCard key={post.slug} post={post} index={i} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Recent posts */}
      <section className="mx-auto max-w-wrap px-6 py-16 sm:px-8 sm:py-20">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-heading text-3xl font-semibold text-sage-900 sm:text-4xl">
            Recent posts
          </h2>
          <Link
            href="/blog"
            className="hidden font-body text-sm font-medium text-sage-700 hover:text-sage-900 sm:inline-block"
          >
            View all →
          </Link>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {recent.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
        <Link
          href="/blog"
          className="mt-8 inline-block font-body text-sm font-medium text-sage-700 hover:text-sage-900 sm:hidden"
        >
          View all posts →
        </Link>
      </section>

      {/* Newsletter */}
      <section className="mx-auto max-w-wrap px-6 pb-20 sm:px-8">
        <Newsletter />
      </section>
    </>
  );
}

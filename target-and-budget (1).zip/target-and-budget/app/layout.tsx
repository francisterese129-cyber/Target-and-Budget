import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cormorant_Garamond, DM_Sans } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-heading",
  display: "swap",
});

const dmSans = DM_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-body",
  display: "swap",
});

const siteUrl = "https://www.targetandbudget.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Target & Budget — Budgeting, Saving & Making Money Online",
    template: "%s | Target & Budget",
  },
  description:
    "Practical, plain-spoken guidance on budgeting, saving, side hustles, and making money online — for people building a financial plan around real life.",
  openGraph: {
    type: "website",
    siteName: "Target & Budget",
    title: "Target & Budget — Budgeting, Saving & Making Money Online",
    description:
      "Practical, plain-spoken guidance on budgeting, saving, side hustles, and making money online.",
    url: siteUrl,
  },
  twitter: {
    card: "summary_large_image",
    title: "Target & Budget",
    description:
      "Practical, plain-spoken guidance on budgeting, saving, side hustles, and making money online.",
  },
  icons: {
    icon: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="en" className={`${cormorant.variable} ${dmSans.variable}`}>
      <body className="flex min-h-screen flex-col bg-cream font-body text-ink antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-sage-800 focus:px-4 focus:py-2 focus:text-cream"
        >
          Skip to content
        </a>
        <Header />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}

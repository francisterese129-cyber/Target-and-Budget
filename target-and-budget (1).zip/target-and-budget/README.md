# Target & Budget

A personal finance blog built with **Next.js 15** (App Router) and **React 19**,
covering budgeting, saving, making money online, and side hustles.

- Clean, minimal design in a sage green palette
- Google Fonts: **Cormorant Garamond** (headings) + **DM Sans** (body)
- Pages: Home, Blog Posts (with category filtering), individual post pages,
  About Me, Contact (working form UI), Privacy Policy
- Responsive, keyboard-accessible, `prefers-reduced-motion`-aware
- SEO basics included: per-page metadata, Open Graph tags, `sitemap.xml`,
  `robots.txt`

## Getting started

Requires Node.js 18.18+ (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

```bash
npm run build   # production build
npm run start   # run the production build locally
npm run lint    # lint the project
```

## Project structure

```
app/
  layout.tsx              Root layout — fonts, global <head>, header/footer
  page.tsx                Home page
  blog/page.tsx            Blog listing + category filter
  blog/[slug]/page.tsx      Individual post page
  about/page.tsx           About Me
  contact/page.tsx          Contact page (renders ContactForm)
  contact/ContactForm.tsx   Client-side form logic
  privacy-policy/page.tsx  Privacy Policy
  api/contact/route.ts     Handles contact + newsletter form submissions
  sitemap.ts / robots.ts   SEO routes
components/                Header, Footer, PostCard, Newsletter, etc.
lib/posts.ts               Blog post content (sample data — replace freely)
```

## Content

All blog posts live in `lib/posts.ts` as plain objects — no CMS or database
required to get started. Each post has a `slug`, `category`
(`Budgeting` | `Saving` | `Making Money Online` | `Side Hustles`), and a
`content` array of paragraph strings.

To add a post, add a new object to the `posts` array. The blog index,
category filters, and sitemap all update automatically. If you outgrow plain
objects, this is a natural place to swap in MDX, a headless CMS (Sanity,
Contentful), or a database — the rest of the site only depends on the
exported functions (`getPostBySlug`, `getPostsByCategory`, etc.), not the
storage format.

## Wiring up the contact form and newsletter

`app/api/contact/route.ts` currently validates submissions and returns
success, but does **not** send email or store data anywhere yet. Before
relying on it in production, connect a provider, for example:

- **Email delivery:** [Resend](https://resend.com), Postmark, or SendGrid to
  email yourself contact form submissions.
- **Newsletter:** ConvertKit, Beehiiv, Mailchimp, or Buttondown to store
  subscribers and send campaigns.

Both are marked with `// TODO` comments in `route.ts`.

## Before you deploy

- Replace `https://www.targetandbudget.com` in `app/layout.tsx`,
  `app/sitemap.ts`, and `app/robots.ts` with your real domain.
- Replace the placeholder contact email in
  `app/privacy-policy/page.tsx` and finish wiring the contact/newsletter
  provider described above.
- Have the Privacy Policy reviewed for your actual data practices and
  jurisdiction — it ships as a clearly-labeled starting template, not legal
  advice.
- Swap the generated `public/favicon.svg` for real branding if desired, and
  add an Open Graph image (`public/og-image.jpg`, referenced from
  `app/layout.tsx`) for richer link previews on social media.

## Deploying

The project is a standard Next.js app and deploys cleanly to
[Vercel](https://vercel.com) (`vercel deploy`), Netlify, or any Node hosting
that supports Next.js 15.

## Design notes

- **Palette:** sage greens (`sage-50`–`sage-900`) on a warm cream
  background, with a muted gold accent reserved for emphasis (CTAs,
  category highlights, the "savings" bar).
- **Type:** Cormorant Garamond for headings (serif, editorial), DM Sans for
  body copy and UI — configured via `next/font/google` in `app/layout.tsx`,
  no external font requests at runtime.
- **Signature motifs:** a torn-receipt edge divider (`.receipt-edge` in
  `globals.css`) and a dotted "ledger rule" underline, both nodding to the
  site's budgeting subject matter, plus an animated allocation-bar graphic
  in the hero instead of a stock photo.

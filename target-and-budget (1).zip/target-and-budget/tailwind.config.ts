import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: "#FAF8F2",
        paper: "#FFFFFF",
        sage: {
          50: "#F1F4EE",
          100: "#E2E9DC",
          200: "#C8D5BE",
          300: "#A9BC9C",
          400: "#87A177",
          500: "#6B8862",
          600: "#556E4C",
          700: "#43573E",
          800: "#354533",
          900: "#212D1E",
        },
        gold: {
          400: "#C9A46A",
          500: "#B58A4A",
          600: "#96703A",
        },
        ink: "#242821",
      },
      fontFamily: {
        heading: ["var(--font-heading)", "Georgia", "serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        grain: "url('/grain.svg')",
      },
      maxWidth: {
        prose: "42rem",
        wrap: "72rem",
      },
      keyframes: {
        fillbar: {
          "0%": { width: "0%" },
          "100%": { width: "var(--fill-to, 70%)" },
        },
        rise: {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        fillbar: "fillbar 1.1s cubic-bezier(0.22,1,0.36,1) forwards",
        rise: "rise 0.6s ease-out forwards",
      },
    },
  },
  plugins: [],
};

export default config;
